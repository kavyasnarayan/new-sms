package com.cg.sms.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;
import com.cg.sms.service.IStudentService;
import com.cg.sms.service.StudentServiceImpl;

public class StudentUI {
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) throws StudentException {
		int choice = 0;
		StudentDTO student = null;
		StudentServiceImpl studentServiceImpl = null;
		IStudentService service = null;
		String decision="";
		
		do {
		System.out.println("1.Add new Student");
		System.out.println("2.Show student details");
		System.out.println("3.Fetch Student Details");
		System.out.println("4.Exit");
		System.out.println("Enter your choice(1-4)");

		try {
			choice = input.nextInt();
			studentServiceImpl = new StudentServiceImpl();
			service = new StudentServiceImpl();
			
				switch (choice) {
				case 1:
					System.out.println("Add new Student");
					System.out.println("Enter Student name");
					String StudentName = input.next();

					System.out.println("Enter Student fees");
					double Fees = input.nextDouble();
					System.out.println("Enter DOB");
					String DOB = input.next();
					DateTimeFormatter formatter = DateTimeFormatter
							.ofPattern("dd/MM/yyyy");
					LocalDate date = LocalDate.parse(DOB, formatter);

					System.out.println("Enter MobileNumber");
					String MobileNumber = input.next();

					student = new StudentDTO();
					student.setStudentName(StudentName);

					student.setFees(Fees);
					student.setDOB(date);
					student.setMobileNumber(MobileNumber);

					try {

						if (studentServiceImpl.StudentValidation(student)) {
							System.out.println("Validated");
							System.out.println("Student Inserted successfully with student id as :: "+service.addStudent(student));
						}
						
					}

					catch (StudentException exp) {
						System.err.println(exp.getMessage() + ". Please try again");
					}

					break;

				case 2:
					service = new StudentServiceImpl();
					System.out.println("Enter the student roll number");
					String rollNo = input.next();
					while (true) {
						if (studentServiceImpl.validateRollNo(rollNo)) {
							break;
						} else {
							System.err
									.println("Please enter valid student number only, try again");
							System.out.println("Enter the student roll number");
							rollNo = input.next();
						}
					}

					student = service.showStudentDetails(rollNo);
					if (student != null) {
						System.out.println(" Student Details");
						System.out.println("Student Name   :"
								+ student.getStudentName()
								+ "  Student Roll No:" + student.getRollNo()
								+ "  Student fees   :" + student.getFees()
								+ "  Student DOB    :" + student.getDOB()
								+ "  Student Mobile Number:"
								+ student.getMobileNumber());
					} else {
						System.err.println("No students are inserted still");
					}

					break;

				case 3:
					List<StudentDTO> list = new ArrayList<StudentDTO>();
					list = service.retrieveStudentDetails();

					for (StudentDTO studentbean : list) {
						System.out.println("Student Name   :"
								+ studentbean.getRollNo()
								+ "  Student Roll No:"
								+ studentbean.getStudentName()
								+ "  Student fees   :" + studentbean.getFees()
								+ "  Student DOB    :" + studentbean.getDOB()
								+ "  Student Mobile Number:"
								+ studentbean.getMobileNumber());
					}

					break;
				case 4:
					System.out.println("Exit ");
					System.exit(0);
					break;

				default:
					System.out.println("Enter numbers from 1 to 4");
					break;
				}
				System.out.println("Do you want to continue further(yes/no)?");
				 decision = input.next();
				
			} 
		catch (InputMismatchException exp) {
//			System.out.println("Enter your choice(1-4)");
//			choice = input.nextInt();
			System.out.println("Enter a numeric number and try again. ");
			//throw new StudentException("Enter a numeric number and try again. "+exp.getMessage());
		}
	}while (decision.equals("yes"));
		if(decision.equals("no")){
			System.out.println("Exit");
		}
		input.close();
	}
}
