package com.cg.sms.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.dao.IStudentDao;
import com.cg.sms.dao.StudentDaoImpl;
import com.cg.sms.exception.StudentException;

public class StudentServiceImpl implements IStudentService {

	public boolean StudentValidation(StudentDTO obj) throws StudentException {
		String errorMessage = "";
		String studentName = null;
		double fees = 0.0;
		String MobileNumber = null;

		// validating student name
		studentName = obj.getStudentName();
		Pattern studentnamePattern = Pattern.compile("^[A-Z][A-Za-z]{3,10}$");
		Matcher nameMatcher = studentnamePattern.matcher(studentName);
		if (!(nameMatcher.matches())) {
			errorMessage += "\nStudent Name Should start with Capital letter and minimum 3 characters long.";
		}

		// validating MobileNumber
		MobileNumber = obj.getMobileNumber();

		Pattern mobilePattern = Pattern.compile("^\\d{10}$");
		Matcher mobileMatcher = mobilePattern.matcher(MobileNumber);

		if (!(mobileMatcher.matches())) {
			errorMessage += "\nMobile Number Should be in 10 digit";

		}
		// validating fees
		fees = obj.getFees();
		if (fees <= 0) {
			errorMessage += "\nfees should be positive number.";
		}
		if (!errorMessage.isEmpty()) {
			throw new StudentException(errorMessage);

		}
		return true;

	}

	public boolean validateRollNo(String rollNo) {
		boolean result=false;
		Pattern rollPattern = Pattern.compile("\\d{2}");
		Matcher rollMatcher = rollPattern.matcher(rollNo);

		if (rollMatcher.matches()){
		result=true;
		}
			return result;
	}

	@Override
	public String addStudent(StudentDTO obj) throws StudentException {
		IStudentDao dao = new StudentDaoImpl();
		return dao.insertStudentDetails(obj);
	}

	public StudentDTO showStudentDetails(String rollNo) throws StudentException {
		
		return new StudentDaoImpl().viewStudentDetails(rollNo);

	}

	@Override
	public List<StudentDTO> retrieveStudentDetails() throws StudentException {

		return new StudentDaoImpl().retrieveStudentDetails();
	}

}
