package com.cg.sms.service;

import java.util.List;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;

public interface IStudentService {

	String addStudent(StudentDTO obj) throws  StudentException;
	StudentDTO showStudentDetails(String rollNo) throws StudentException;

	public boolean validateRollNo(String rollNo) ;
	List<StudentDTO> retrieveStudentDetails() throws StudentException;
	
}
