package com.cg.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;
import com.cg.sms.util.DBConnection;

public class StudentDaoImpl implements IStudentDao {

	public String insertStudentDetails(StudentDTO dto) throws StudentException {
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		ResultSet resultSet = null;
		int queryResult = -1;
		String rollNo = "";
		try {
			connection.setAutoCommit(false);
			preparedStatement = connection
					.prepareStatement(QueryMapping.INSERT_QUERY);
			preparedStatement.setString(1, dto.getStudentName());
			preparedStatement.setDouble(2, dto.getFees());
			preparedStatement.setDate(3, java.sql.Date.valueOf(dto.getDOB()));
			preparedStatement.setString(4, dto.getMobileNumber());
			queryResult = preparedStatement.executeUpdate();
			if (queryResult == 1) {
				connection.commit();
				preparedStatement1 = connection
						.prepareStatement(QueryMapping.DONARID_QUERY_SEQUENCE);
				resultSet = preparedStatement1.executeQuery();
				if (resultSet.next()) {
					rollNo = resultSet.getInt(1) + "";
				}
			}
		} catch (SQLException exception) {
			try {
				connection.rollback();
			} catch (SQLException e) {
				throw new StudentException(e.getMessage());
			}
			throw new StudentException(exception.getMessage());
		} finally {
			if (preparedStatement != null && preparedStatement1 != null
					&& connection != null) {
				try {
					resultSet.close();
					preparedStatement.close();
				} catch (SQLException exception) {
					throw new StudentException(exception.getMessage());
				}
			}
		}
		return rollNo;

	}

	public StudentDTO viewStudentDetails(String rollNo) throws StudentException {

		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		StudentDTO student = null;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapping.VIEW_DONAR_DETAILS_QUERY);
			preparedStatement.setString(1, rollNo);
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
				student = new StudentDTO();
				student.setRollNo(resultset.getString(1));
				student.setStudentName(resultset.getString(2));
				student.setFees(resultset.getDouble(3));
				student.setDOB(resultset.getDate(4).toLocalDate());
				student.setMobileNumber(resultset.getString(5));
			}

		} catch (SQLException exception) {
			throw new StudentException(exception.getMessage());

		} finally {
			try {
				resultset.close();
				preparedStatement.close();
			} catch (SQLException exception) {
				throw new StudentException(exception.getMessage());
			}
		}

		return student;

	}

	@Override
	public List<StudentDTO> retrieveStudentDetails() throws StudentException {

		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		List<StudentDTO> list = new ArrayList<StudentDTO>();

		try {
			preparedStatement = connection
					.prepareStatement(QueryMapping.RETRIVE_ALL_QUERY);
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
				StudentDTO student = new StudentDTO();
				student.setRollNo(resultset.getString(1));
				student.setStudentName(resultset.getString(2));
				student.setFees(resultset.getDouble(3));
				student.setDOB(resultset.getDate(4).toLocalDate());
				student.setMobileNumber(resultset.getString(5));
				list.add(student);
			}
		} catch (SQLException exception) {
			throw new StudentException(exception.getMessage());
		} finally {
			if (preparedStatement != null && connection != null
					&& resultset != null) {
				try {
					resultset.close();
					preparedStatement.close();
				} catch (SQLException exception) {
					throw new StudentException(exception.getMessage());
				}
			}
		}
		return list;
	}

}