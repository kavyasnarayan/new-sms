package com.cg.sms.dao;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;

public class StudentDaoImplTest {
IStudentDao dao;
	@Before
	public void setUp() throws Exception {
		dao=new StudentDaoImpl();
	}

	@Test
	public void testInsertStudentDetails1() {
		StudentDTO  studentDTO=new StudentDTO();
		studentDTO.setStudentName("maanasa");
		studentDTO.setMobileNumber("3216547809");
		studentDTO.setFees(32156.01);
		studentDTO.setDOB(LocalDate.now());
		try {
			String sid=dao.insertStudentDetails(studentDTO);
			assertNotSame("16", sid.trim());
		} catch (StudentException e) {
			fail(" exception occured "+e.getMessage());
		}
	}
	public void testInsertStudentDetails2() {
		StudentDTO  studentDTO=new StudentDTO();
		studentDTO.setStudentName("maanasa111");
		studentDTO.setMobileNumber("3216542309");
		studentDTO.setFees(56156.01);
		studentDTO.setDOB(LocalDate.now());
		try {
			String sid=dao.insertStudentDetails(studentDTO);
			assertNotSame("24", sid.trim());
		} catch (StudentException e) {
			fail(" exception occured "+e.getMessage());
		}
	}

	@Test
	public void testRetrieveStudentDetails() {
		try {
			List<StudentDTO> list=dao.retrieveStudentDetails();
			assertNotNull(list);
		} catch (StudentException e) {
			fail(" exception occured "+e.getMessage());
		}
	}

}
